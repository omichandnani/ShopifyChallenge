package com.ec.lab;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.sql.Blob;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.List; 
import java.util.Date;
import java.util.Iterator; 
import org.apache.log4j.Logger;


public class AddProduct {
	
	private static final Log log = LogFactory.getLog(AddProduct.class);
	
	public String save()
	{
		
		String product = "Clothes";
		int price = 500;
		int inventorycount = 10;
		
		Product s1 = new Product();
		s1.setProduct(product);
		s1.setPrice(price);
		s1.setInventorycount(inventorycount);
		
		try {
			SessionFactory sessionFactory = new Configuration().configure(
					"/hibernate.cfg.xml").buildSessionFactory();

			Session s = sessionFactory.openSession();

			Transaction tx = s.beginTransaction();
			/*Object retrive =new Object();
			retrive=s1.getPhoto();*/
			
			 
    	    s.save(s1);
			tx.commit();
			s.close();
		} catch (Exception e) {
			System.err.println("Initial SessionFactory creation failed." + e);
		}
	
	
	
	return product;
		
	}
	
	
	
	
	public String Productreturn(String products)
	{
		
		
		String result="";
		int count;


		try {
			SessionFactory sessionFactory = new Configuration().configure(
					"/hibernate.cfg.xml").buildSessionFactory();

			Session s = sessionFactory.openSession();

			Transaction tx = s.beginTransaction();
			Object retrive =new Object();
			
			
			
	         List productlist = s.createQuery("FROM Product").list(); 
	         for (Iterator iterator = productlist.iterator(); iterator.hasNext();){
	            Product productt = (Product) iterator.next(); 
	            
	            result=productt.getProduct();
	            if(result!=null && result.equalsIgnoreCase(products))
	            	
	            	
{
	            	count=productt.getInventorycount();
	            	
	            	if(count>0)
	            		
	            	{
	            		count--;
	            		productt.setInventorycount(count);
	            		
	            		s.save(productt);
	            	}
	            	
	            	
}
	         }
	            //System.out.print("  Last Name: " + employee.getLastName()); 
	           // System.out.println("  Salary: " + employee.getSalary()); 
			

			

			tx.commit();
			s.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.err.println("Initial SessionFactory creation failed." + e);
		}
	
	
	
	return result;
		
	}
	
	/*
	public String Password()
	{
		File file = new File("C:/tmp/enterprise/model/kmeans.bin");
        byte[] bFile = new byte[(int) file.length()];
		
		String result="";


		try {
			SessionFactory sessionFactory = new Configuration().configure(
					"/hibernate.cfg.xml").buildSessionFactory();

			Session s = sessionFactory.openSession();

			
			Transaction tx = s.beginTransaction();
			Object retrive =new Object();
			retrive=s1.getPhoto();
			
	         List employees = s.createQuery("FROM Student").list(); 
	         for (Iterator iterator = employees.iterator(); iterator.hasNext();){
	            Student employee = (Student) iterator.next(); 
	            System.out.print("First Name: " + employee.getPassword()); 
	            
	            result=employee.getPassword().toString();
	         }
	 		

				tx.commit();
				s.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				System.err.println("Initial SessionFactory creation failed." + e);
			}
		
		
		
		return result;
			
		}

	
	*/
	
	
	public static void main(String args[]) throws Exception {

		
		System.out.println("Added to Database");
		AddProduct s=new AddProduct();
		log.info("Adding The record in the database .");

		
	//	s.save();
		s.Productreturn("Clothes");
	}// end of method
}// end of class