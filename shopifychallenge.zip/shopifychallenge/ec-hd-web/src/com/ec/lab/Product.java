package com.ec.lab;

import java.io.Serializable;
import java.sql.Blob;

public class Product implements Serializable {
	private long id;
	private String product;
	private int price;
	private int inventorycount;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getInventorycount() {
		return inventorycount;
	}
	public void setInventorycount(int inventorycount) {
		this.inventorycount = inventorycount;
	}
	
	
}
